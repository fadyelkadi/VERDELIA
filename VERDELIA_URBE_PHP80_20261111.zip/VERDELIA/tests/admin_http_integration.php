<?php
declare(strict_types=1);

if(PHP_SAPI!=='cli'||PHP_VERSION_ID<80000||!extension_loaded('pdo_mysql')||!extension_loaded('curl')){fwrite(STDERR,"Se requieren PHP CLI 8+, pdo_mysql y curl.\n");exit(1);}
require dirname(__DIR__).'/scripts/migrations.php';
$config=require dirname(__DIR__).'/config/database.php';
$backup=$argv[1]??dirname(__DIR__).'/database/backups/verdelia_20261103_183812.sql';
$database='verdelia_admin_http_'.gmdate('Ymd_His').'_'.bin2hex(random_bytes(3));$created=false;$assertions=0;$handles=[];$process=null;$stdout=null;$stderr=null;$exitCode=0;
$assert=static function(bool $ok,string $message)use(&$assertions):void{if(!$ok)throw new RuntimeException('FALLÓ: '.$message);$assertions++;};
try{
  $server=new PDO(sprintf('mysql:host=%s;port=%d;charset=utf8mb4',$config['host'],$config['port']),$config['user'],$config['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false,PDO::ATTR_TIMEOUT=>5]);
  $sql=file_get_contents($backup);if($sql===false)throw new RuntimeException('No se pudo leer el respaldo aislado.');
  $sql=preg_replace('/CREATE DATABASE IF NOT EXISTS `verdelia_demo`/','CREATE DATABASE IF NOT EXISTS `'.$database.'`',$sql,1,$createdCount);$sql=preg_replace('/USE `verdelia_demo`/','USE `'.$database.'`',$sql,1,$usedCount);
  if($createdCount!==1||$usedCount!==1||!is_string($sql))throw new RuntimeException('Respaldo VERDELIA inválido.');
  $server->exec('CREATE DATABASE `'.$database.'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');$created=true;foreach(preg_split('/;\s*(?:\r?\n|$)/',$sql)as$statement)if(trim($statement)!=='')$server->exec($statement);$server->exec('USE `'.$database.'`');verdelia_apply_migrations($server);
  // Normalizar la cuenta únicamente en la copia temporal, independientemente del respaldo elegido.
  $server->prepare('UPDATE users SET password_hash=? WHERE email=?')->execute([password_hash('123456789',PASSWORD_BCRYPT),'admin@verdelia.test']);
  $socket=stream_socket_server('tcp://127.0.0.1:0',$errno,$error);if(!$socket)throw new RuntimeException('No se pudo reservar un puerto local: '.$error);$address=stream_socket_get_name($socket,false);fclose($socket);$port=(int)substr(strrchr((string)$address,':'),1);$base='http://127.0.0.1:'.$port;
  $logPath=dirname(__DIR__).'/storage/logs/admin-http-test-'.$port.'.log';if(!is_dir(dirname($logPath)))mkdir(dirname($logPath),0775,true);$stdout=fopen($logPath,'a');$stderr=fopen($logPath,'a');if(!$stdout||!$stderr)throw new RuntimeException('No se pudo abrir log temporal del servidor.');
  $env=getenv();if(!is_array($env))$env=[];$env['VERDELIA_DB_NAME']=$database;$env['VERDELIA_DB_HOST']=$config['host'];$env['VERDELIA_DB_PORT']=(string)$config['port'];$env['VERDELIA_DB_USER']=$config['user'];$env['VERDELIA_DB_PASSWORD']=$config['password'];
  $startServer=static function()use(&$process,$env,$port,$stdout,$stderr):void{$spec=[0=>['pipe','r'],1=>$stdout,2=>$stderr];$process=proc_open([PHP_BINARY,'-S','127.0.0.1:'.$port,'-t',dirname(__DIR__).'/public',dirname(__DIR__).'/public/router.php'],$spec,$pipes,dirname(__DIR__),$env);if(!is_resource($process))throw new RuntimeException('No se pudo iniciar servidor PHP aislado.');if(is_resource($pipes[0]))fclose($pipes[0]);};
  $stopServer=static function()use(&$process):void{if(is_resource($process)){proc_terminate($process);proc_close($process);$process=null;}};
  $startServer();
  $request=static function(CurlHandle $client,string $method,string $path,array $data=[])use($base):array{$location='';$headers=['Accept: text/html','Connection: close'];$options=[CURLOPT_URL=>$base.$path,CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_CONNECTTIMEOUT=>2,CURLOPT_TIMEOUT=>8,CURLOPT_HEADERFUNCTION=>static function($curl,string $line)use(&$location):int{if(stripos($line,'Location:')===0)$location=trim(substr($line,9));return strlen($line);},CURLOPT_HTTPGET=>$method==='GET',CURLOPT_POST=>false,CURLOPT_CUSTOMREQUEST=>$method];if($method==='POST'){$options[CURLOPT_POST]=true;$options[CURLOPT_HTTPGET]=false;$options[CURLOPT_CUSTOMREQUEST]='POST';$options[CURLOPT_POSTFIELDS]=http_build_query($data);$headers[]='Content-Type: application/x-www-form-urlencoded';}$options[CURLOPT_HTTPHEADER]=$headers;curl_setopt_array($client,$options);$body=curl_exec($client);if(!is_string($body))throw new RuntimeException('Fallo HTTP: '.curl_error($client));return ['status'=>(int)curl_getinfo($client,CURLINFO_RESPONSE_CODE),'location'=>$location,'body'=>$body];};
  $newClient=static function()use(&$handles):CurlHandle{$client=curl_init();curl_setopt_array($client,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_COOKIEFILE=>'',CURLOPT_CONNECTTIMEOUT=>2,CURLOPT_TIMEOUT=>8]);$handles[]=$client;return $client;};
  $csrf=static function(string $body):string{if(preg_match('/<meta name="csrf-token" content="([a-f0-9]+)"/',$body,$m)!==1)throw new RuntimeException('No se encontró CSRF en página.');return $m[1];};
  $guest=$newClient();$unauth=$request($guest,'GET','/admin');$assert($unauth['status']===303&&str_starts_with($unauth['location'],'/login'),'sin sesión recibe redirección al login');$guestAnalytics=$request($guest,'GET','/admin/analitica');$assert($guestAnalytics['status']===303&&str_starts_with($guestAnalytics['location'],'/login'),'analítica requiere iniciar sesión');
  $customer=$newClient();$loginPage=$request($customer,'GET','/login');$login=$request($customer,'POST','/login',['csrf_token'=>$csrf($loginPage['body']),'email'=>'cliente@verdelia.test','password'=>'VerdeliaCliente2026!']);$assert($login['status']===303,'el cliente demo inicia sesión; status='.$login['status'].' location='.$login['location'].' response='.substr(strip_tags($login['body']),0,180));
  $denied=$request($customer,'GET','/admin');$assert($denied['status']===403,'un cliente recibe 403 al consultar admin');$customerAnalytics=$request($customer,'GET','/admin/analitica');$assert($customerAnalytics['status']===403,'un cliente no consulta la analítica');
  $clientWrite=$request($customer,'POST','/admin/productos/guardar',['name'=>'No permitido']);$assert($clientWrite['status']===403,'cliente no ejecuta un POST administrativo directo');
  $admin=$newClient();$adminLoginPage=$request($admin,'GET','/login');$adminLogin=$request($admin,'POST','/login',['csrf_token'=>$csrf($adminLoginPage['body']),'email'=>'admin@verdelia.test','password'=>'123456789']);$assert($adminLogin['status']===303&&$adminLogin['location']==='/admin','administrador llega al panel');
  $dashboard=$request($admin,'GET','/admin');$assert($dashboard['status']===200&&str_contains($dashboard['body'],'Ventas confirmadas')&&str_contains($dashboard['body'],'Productos activos'),'dashboard entrega indicadores dinámicos');
  $analysisSku=(string)$server->query("SELECT oi.sku_snapshot FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.sku_snapshot<>'' AND o.status IN ('PAID','FULFILLED') AND EXISTS(SELECT 1 FROM payments p WHERE p.order_id=o.id AND p.status='APPROVED') ORDER BY oi.id LIMIT 1")->fetchColumn();
  $analytics=$request($admin,'GET','/admin/analitica?desde=2026-05-01&hasta=2026-11-03&periodo=month&producto='.rawurlencode($analysisSku).'&metrica=gross_profit');$assert($analytics['status']===200&&str_contains($analytics['body'],'Regresión lineal')&&str_contains($analytics['body'],'Ajuste exponencial')&&str_contains($analytics['body'],'data-chart="models"')&&str_contains($analytics['body'],'Ganancia bruta')&&str_contains($analytics['body'],'Producto para la regresión')&&str_contains($analytics['body'],'Resultado del producto elegido')&&str_contains($analytics['body'],$analysisSku),'ADMIN consulta regresión de ganancia del SKU elegido y las gráficas generales');
  $revenueAnalytics=$request($admin,'GET','/admin/analitica?desde=2026-05-01&hasta=2026-11-03&periodo=month&producto='.rawurlencode($analysisSku).'&metrica=revenue');$assert($revenueAnalytics['status']===200&&str_contains($revenueAnalytics['body'],'Ingresos por ventas ·')&&str_contains($revenueAnalytics['body'],'value="revenue" selected'),'ADMIN cambia el modelo de rentabilidad a ingresos del mismo SKU');
  $analyticsInvalid=$request($admin,'GET','/admin/analitica?desde=2026-02-31&hasta=2026-03-02&periodo=day');$assert($analyticsInvalid['status']===200&&str_contains($analyticsInvalid['body'],'fecha inicial no es válida'),'filtro rechaza fecha inválida y conserva respuesta segura');
  $productsPage=$request($admin,'GET','/admin/productos/nuevo');$assert($productsPage['status']===200&&str_contains($productsPage['body'],'Imagen local'),'formulario ofrece selector de imágenes locales');
  $missingCsrf=$request($admin,'POST','/admin/productos/guardar',['sku'=>'ADM-811']);$assert($missingCsrf['status']===419,'mutación administrativa sin CSRF se rechaza');
  $create=$request($admin,'POST','/admin/productos/guardar',['csrf_token'=>$csrf($productsPage['body']),'sku'=>'HTTP-811','slug'=>'producto-http-admin','name'=>'Producto HTTP Admin','scientific_name'=>'','description'=>'Producto temporal HTTP','category_id'=>'1','price'=>'19.95','cost'=>'7.25','initial_stock'=>'4','light'=>'Indirecta','care_level'=>'Fácil','image'=>'PLA-001-aloe-vera.png','active'=>'1']);
  $assert($create['status']===303&&preg_match('#^/admin/productos/[1-9]\d*/editar$#',$create['location'])===1,'administrador crea producto por HTTP');
  $list=$request($admin,'GET','/admin/productos?q=HTTP-811');$assert($list['status']===200&&str_contains($list['body'],'Producto HTTP Admin'),'producto aparece en listado filtrado');
  $store = $request($customer, 'GET', '/tienda');
  $chatToken = $csrf($store['body']);
  curl_setopt_array($customer, [
    CURLOPT_URL => $base.'/api/chat',
    CURLOPT_POST => true,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_HTTPHEADER => ['Accept: application/json', 'Content-Type: application/json', 'X-CSRF-Token: '.$chatToken],
  ]);
  foreach ([
    ['¿Cuánto cuesta el Bambú de la Suerte?', '/producto/bambu-de-la-suerte', '$18.00'],
    ['¿Cuánto cuesta HTTP-811?', '/producto/producto-http-admin', '$19.95'],
  ] as [$message, $expectedUrl, $expectedPrice]) {
    curl_setopt($customer, CURLOPT_POSTFIELDS, json_encode(['message' => $message], JSON_THROW_ON_ERROR));
    $reply = curl_exec($customer);
    $chat = is_string($reply) ? json_decode($reply, true) : null;
    $assert(
      curl_getinfo($customer, CURLINFO_RESPONSE_CODE) === 200
        && ($chat['ok'] ?? false) === true
        && ($chat['products'][0]['url'] ?? '') === $expectedUrl
        && str_contains($chat['message'] ?? '', $expectedPrice),
      'el chat identifica producto y precio para «'.$message.'»'
    );
  }
  $negative=$request($admin,'POST','/admin/productos/guardar',['csrf_token'=>$csrf($list['body']),'sku'=>'HTTP-812','slug'=>'producto-http-negativo','name'=>'Producto negativo','category_id'=>'1','price'=>'-1','cost'=>'1.00','initial_stock'=>'2','image'=>'PLA-001-aloe-vera.png','active'=>'1']);
  $errorPage=$request($admin,'GET',$negative['location']);$assert($errorPage['status']===200&&str_contains($errorPage['body'],'Precio debe ser'),'precio negativo muestra error y no se persiste');
  $csrfToken=$csrf($errorPage['body']);$inventory=$request($admin,'GET','/admin/inventario');preg_match('/name="product_id" value="(\d+)"[^>]*>\s*<input type="hidden" name="sku" value="HTTP-811"[^>]*>\s*<input type="hidden" name="expected_stock" value="(\d+)"/',$inventory['body'],$match);
  if(($match[1]??'')===''||($match[2]??'')===''){
    $id=(int)basename(dirname($create['location']));$dbProduct=$server->query("SELECT id,stock FROM products WHERE sku='HTTP-811'")->fetch();$match=[null,(string)$dbProduct['id'],(string)$dbProduct['stock']];
  }
  $stockPost=$request($admin,'POST','/admin/inventario/ajustar',['csrf_token'=>$csrfToken,'product_id'=>$match[1],'sku'=>'HTTP-811','expected_stock'=>$match[2],'delta'=>'3','reason'=>'Recepción HTTP']);$assert($stockPost['status']===303,'ajuste de inventario responde por formulario protegido');
  $assert((int)$server->query("SELECT stock FROM products WHERE sku='HTTP-811'")->fetchColumn()===7,'ajuste HTTP se guarda en MariaDB');
  $categoryPage=$request($admin,'GET','/admin/categorias');$duplicate=$request($admin,'POST','/admin/categorias/guardar',['csrf_token'=>$csrf($categoryPage['body']),'name'=>'Plantas de interior','slug'=>'interior-duplicado','description'=>'','active'=>'1']);$duplicatePage=$request($admin,'GET',$duplicate['location']);$assert(str_contains($duplicatePage['body'],'Ya existe una categoría'),'categoría duplicada muestra rechazo');
  $customers=$request($admin,'GET','/admin/clientes?q=cliente%40verdelia.test');$assert($customers['status']===200&&str_contains($customers['body'],'cliente@verdelia.test')&&!str_contains($customers['body'],'VerdeliaCliente2026!'),'búsqueda de clientes no expone claves');
  $orders=$request($admin,'GET','/admin/pedidos?estado=PAID');$assert($orders['status']===200&&str_contains($orders['body'],'SIM-DEMO-'),'filtro de pedidos presenta pagos y referencias simuladas');
  $receipt=$request($admin,'GET','/admin/pedidos/DEMO-00096/recibo');$assert($receipt['status']===200&&str_contains($receipt['body'],'DEMO-00096')&&str_contains($receipt['body'],'SIM-DEMO-00096'),'admin puede abrir recibo histórico con pago simulado');
  $orderPage=$request($admin,'GET','/admin/pedidos/DEMO-00096');$assert($orderPage['status']===200&&str_contains($orderPage['body'],'Historial de estado'),'detalle ofrece gestión operativa auditada');
  $forgedClient=$request($customer,'POST','/admin/pedidos/DEMO-00096/estado',['csrf_token'=>$csrf($loginPage['body']),'status'=>'FULFILLED','reason'=>'forjado']);$assert($forgedClient['status']===403,'cliente no puede cambiar estado aunque envíe token');
  $orderCsrf=$csrf($orderPage['body']);$transition=$request($admin,'POST','/admin/pedidos/DEMO-00096/estado',['csrf_token'=>$orderCsrf,'status'=>'FULFILLED','reason'=>'Entrega HTTP de prueba']);$assert($transition['status']===303,'admin ejecuta transición válida');
  $assert((string)$server->query("SELECT status FROM orders WHERE order_number='DEMO-00096'")->fetchColumn()==='FULFILLED','estado persiste en MariaDB');
  $stopServer();$startServer();$afterRestart=$request($admin,'GET','/admin/productos?q=HTTP-811');$assert($afterRestart['status']===200&&str_contains($afterRestart['body'],'Producto HTTP Admin'),'producto permanece tras reiniciar servidor PHP');
  echo "Admin HTTP aislado aprobado: {$assertions} aserciones; permisos, CSRF, catálogo, inventario, categorías, clientes, pedidos, recibos y reinicio.\n";
}catch(Throwable $e){fwrite(STDERR,'ERROR: '.$e->getMessage()."\n");if(isset($logPath)&&is_file($logPath))fwrite(STDERR,"Log: {$logPath}\n".implode('',array_slice(file($logPath,FILE_IGNORE_NEW_LINES)?:[],-25))."\n");$exitCode=1;}
finally{if(isset($stopServer))$stopServer();foreach($handles as$h)if($h instanceof CurlHandle)curl_close($h);if(is_resource($stdout))fclose($stdout);if(is_resource($stderr))fclose($stderr);if(isset($logPath)&&is_file($logPath))@unlink($logPath);if(isset($server)&&$created)try{$server->exec('DROP DATABASE IF EXISTS `'.$database.'`');echo "Limpieza: solo se eliminó la BD temporal {$database}.\n";}catch(Throwable){fwrite(STDERR,"ERROR: no se pudo limpiar la BD temporal {$database}.\n");$exitCode=1;}}
if($exitCode!==0)exit($exitCode);
